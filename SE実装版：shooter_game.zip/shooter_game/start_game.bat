@echo off
setlocal
cd /d "%~dp0"
set "PORT=8765"

start "2D Shooting Local Server" /min powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0local_server.ps1" -Port %PORT%
for /l %%i in (1,1,15) do (
  powershell.exe -NoLogo -NoProfile -Command "try { $client = New-Object System.Net.Sockets.TcpClient; $client.Connect('127.0.0.1', %PORT%); $client.Close(); exit 0 } catch { exit 1 }" >nul 2>&1
  if not errorlevel 1 goto open_game
  timeout /t 1 /nobreak >nul
)

:open_game
start "" "http://127.0.0.1:%PORT%/2D_Shooting.html"
endlocal
