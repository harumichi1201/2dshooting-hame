param([int]$Port = 8765)

$root = [System.IO.Path]::GetFullPath($PSScriptRoot)
$rootPrefix = $root.TrimEnd([System.IO.Path]::DirectorySeparatorChar) + [System.IO.Path]::DirectorySeparatorChar
$server = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $Port)
$server.Start()

try {
    while ($true) {
        $client = $server.AcceptTcpClient()
        try {
            $stream = $client.GetStream()
            $reader = [System.IO.StreamReader]::new($stream, [System.Text.Encoding]::ASCII, $false, 1024, $true)
            $requestLine = $reader.ReadLine()
            $rangeHeader = $null
            while (($header = $reader.ReadLine()) -and $header.Length -gt 0) {
                if ($header -match '^Range:\s*bytes=(\d*)-(\d*)') { $rangeHeader = $Matches[1..2] }
            }

            $status = '200 OK'
            $body = [byte[]]@()
            $contentType = 'application/octet-stream'
            $contentRange = ''
            try {
                if (-not $requestLine) { throw 'Bad request' }
                $parts = $requestLine.Split(' ')
                if ($parts.Length -lt 2 -or $parts[0] -ne 'GET') { throw 'Bad request' }
                $urlPath = $parts[1].Split('?')[0]
                $relativePath = [Uri]::UnescapeDataString($urlPath.TrimStart('/'))
                if ([string]::IsNullOrWhiteSpace($relativePath)) { $relativePath = '2D_Shooting.html' }
                $fullPath = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($root, $relativePath))
                if (-not $fullPath.StartsWith($rootPrefix, [System.StringComparison]::OrdinalIgnoreCase) -or -not [System.IO.File]::Exists($fullPath)) {
                    $status = '404 Not Found'
                    $body = [System.Text.Encoding]::UTF8.GetBytes('Not Found')
                } else {
                    $extension = [System.IO.Path]::GetExtension($fullPath).ToLowerInvariant()
                    $contentType = switch ($extension) {
                        '.html' { 'text/html; charset=utf-8' }
                        '.json' { 'application/json; charset=utf-8' }
                        '.wav'  { 'audio/wav' }
                        '.js'   { 'text/javascript; charset=utf-8' }
                        '.css'  { 'text/css; charset=utf-8' }
                        default { 'application/octet-stream' }
                    }
                    $body = [System.IO.File]::ReadAllBytes($fullPath)
                    if ($rangeHeader -and $extension -eq '.wav') {
                        $total = $body.Length
                        $start = if ($rangeHeader[0]) { [int64]$rangeHeader[0] } else { 0 }
                        $end = if ($rangeHeader[1]) { [Math]::Min([int64]$rangeHeader[1], $total - 1) } else { $total - 1 }
                        if ($start -ge $total -or $end -lt $start) {
                            $status = '416 Range Not Satisfiable'
                            $contentRange = "Content-Range: bytes */$total`r`n"
                            $body = [byte[]]@()
                        } else {
                            $length = [int]($end - $start + 1)
                            $partial = [byte[]]::new($length)
                            [Array]::Copy($body, $start, $partial, 0, $length)
                            $body = $partial
                            $status = '206 Partial Content'
                            $contentRange = "Content-Range: bytes $start-$end/$total`r`n"
                        }
                    }
                }
            } catch {
                $status = '400 Bad Request'
                $body = [System.Text.Encoding]::UTF8.GetBytes('Bad Request')
            }

            $responseHeader = "HTTP/1.1 $status`r`nContent-Type: $contentType`r`nContent-Length: $($body.Length)`r`nAccept-Ranges: bytes`r`nCache-Control: no-store`r`n$contentRange`r`n"
            $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($responseHeader)
            $stream.Write($headerBytes, 0, $headerBytes.Length)
            if ($body.Length -gt 0) { $stream.Write($body, 0, $body.Length) }
            $stream.Flush()
            $reader.Dispose()
            $stream.Dispose()
        } catch {
        } finally {
            $client.Close()
        }
    }
} finally {
    $server.Stop()
}
